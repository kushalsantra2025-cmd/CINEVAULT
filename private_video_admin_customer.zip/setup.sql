-- PRIVATE VAULT: Admin publishes; authenticated customers watch.
-- Run in Supabase Dashboard -> SQL Editor.
-- Use a fresh Supabase project, or review existing tables/policies before applying.
-- Never expose service_role/secret keys in the browser.

create extension if not exists pgcrypto;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('private-videos','private-videos',false,524288000,
 array['video/mp4','video/quicktime','video/webm','video/x-msvideo','video/mpeg','video/3gpp','video/x-matroska','video/ogg'])
on conflict (id) do update set public=false,file_size_limit=excluded.file_size_limit,allowed_mime_types=excluded.allowed_mime_types;

create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 email text,
 role text not null default 'customer' check (role in ('admin','customer')),
 created_at timestamptz not null default now()
);

-- If an earlier version of this site created profiles.role with a different check:
alter table public.profiles add column if not exists role text not null default 'customer';
alter table public.profiles drop constraint if exists profiles_role_check;
alter table public.profiles add constraint profiles_role_check check (role in ('admin','customer'));

create table if not exists public.videos (
 id uuid primary key default gen_random_uuid(),
 owner_id uuid not null references auth.users(id) on delete cascade,
 title text not null check (char_length(title) between 1 and 120),
 object_path text not null unique,
 mime_type text not null,
 size_bytes bigint not null check (size_bytes > 0 and size_bytes <= 524288000),
 published boolean not null default true,
 created_at timestamptz not null default now(),
 constraint video_path_owner check (split_part(object_path,'/',1)=owner_id::text),
 constraint video_path_id check (split_part(object_path,'/',2)=id::text)
);
alter table public.videos add column if not exists published boolean not null default true;

create index if not exists videos_created_idx on public.videos(created_at desc);
create index if not exists videos_owner_idx on public.videos(owner_id);

create or replace function public.handle_new_private_vault_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
 insert into public.profiles(id,email,role)
 values(new.id,lower(new.email),'customer')
 on conflict(id) do update set email=excluded.email;
 return new;
end;
$$;

drop trigger if exists on_auth_user_created_private_vault on auth.users;
create trigger on_auth_user_created_private_vault
after insert on auth.users
for each row execute function public.handle_new_private_vault_user();

create or replace function public.is_private_vault_admin()
returns boolean language sql stable security definer set search_path = ''
as $$
 select exists(select 1 from public.profiles p where p.id=(select auth.uid()) and p.role='admin');
$$;

create or replace function public.can_read_private_video_path(p_path text)
returns boolean language sql stable security definer set search_path = ''
as $$
 select exists(
  select 1 from public.videos v
  where v.object_path=p_path and v.published=true
    and (select auth.uid()) is not null
 );
$$;

alter table public.profiles enable row level security;
alter table public.videos enable row level security;

drop policy if exists "Users can read own profile" on public.profiles;
drop policy if exists "Users can read own profile only" on public.profiles;
create policy "Users can read own profile only" on public.profiles
for select to authenticated using (id=(select auth.uid()));

-- No INSERT/UPDATE/DELETE policy for profiles: users cannot promote themselves.
drop policy if exists "Owners and invited users can read video rows" on public.videos;
drop policy if exists "Users can add their own video rows" on public.videos;
drop policy if exists "Owners can update their video rows" on public.videos;
drop policy if exists "Owners can delete their video rows" on public.videos;
drop policy if exists "Customers read published videos and admins read all" on public.videos;
create policy "Customers read published videos and admins read all" on public.videos
for select to authenticated
using (published=true or public.is_private_vault_admin());

drop policy if exists "Only admins can post videos" on public.videos;
create policy "Only admins can post videos" on public.videos
for insert to authenticated
with check (
 public.is_private_vault_admin()
 and owner_id=(select auth.uid())
 and split_part(object_path,'/',1)=(select auth.uid())::text
 and split_part(object_path,'/',2)=id::text
);

drop policy if exists "Only admins can update videos" on public.videos;
create policy "Only admins can update videos" on public.videos
for update to authenticated
using (public.is_private_vault_admin())
with check (public.is_private_vault_admin() and owner_id=(select auth.uid()));

drop policy if exists "Only admins can delete videos" on public.videos;
create policy "Only admins can delete videos" on public.videos
for delete to authenticated using (public.is_private_vault_admin());

-- Remove policies from the previous invitation-based version, if present.
drop policy if exists "Owners and invited viewers can read private videos" on storage.objects;
drop policy if exists "Owners can upload private videos" on storage.objects;
drop policy if exists "Owners can delete private videos" on storage.objects;
drop policy if exists "Admins and customers can read published private videos" on storage.objects;
drop policy if exists "Only admins can upload private videos" on storage.objects;
drop policy if exists "Only admins can delete private videos" on storage.objects;

create policy "Admins and customers can read published private videos" on storage.objects
for select to authenticated
using (bucket_id='private-videos' and public.can_read_private_video_path(name));

create policy "Only admins can upload private videos" on storage.objects
for insert to authenticated
with check (
 bucket_id='private-videos'
 and public.is_private_vault_admin()
 and (storage.foldername(name))[1]=(select auth.uid())::text
 and exists(select 1 from public.videos v where v.object_path=name and v.owner_id=(select auth.uid()))
);

create policy "Only admins can delete private videos" on storage.objects
for delete to authenticated
using (
 bucket_id='private-videos'
 and public.is_private_vault_admin()
 and (storage.foldername(name))[1]=(select auth.uid())::text
);

-- IMPORTANT: Create your account through the website first, confirm the email if required.
-- Then replace the email below with YOUR OWN email and run this statement in SQL Editor.
-- This is the only intended admin promotion path; do not add admin signup to the public website.
-- UPDATE public.profiles SET role='admin' WHERE lower(email)=lower('YOUR-ADMIN-EMAIL@example.com');
