PRIVATE VAULT — Admin & Customer (বাংলা সেটআপ)
================================================

এই version-এ:
- Customer Login: customer account তৈরি করে লগইন, শুধু admin-এর published video দেখা।
- Admin Login: admin video upload/publish/delete করতে পারে।
- Public signup দিয়ে admin হওয়া যায় না; role database-এ থাকে।
- Private Supabase Storage bucket + RLS policies + 5-minute signed playback URL।
- Mobile-friendly Premium Black UI।

ফাইল:
- index.html — ওয়েবসাইট
- setup.sql — Supabase SQL setup
- README.txt — এই নির্দেশিকা

SETUP 1 — Supabase
1. https://supabase.com এ নতুন project তৈরি করো।
2. SQL Editor → New query → setup.sql-এর সব কোড paste করে Run করো।
3. Storage → Buckets-এ private-videos bucket তৈরি হয়েছে এবং Public OFF আছে নিশ্চিত করো।
4. Authentication → Providers → Email চালু রাখো। নিরাপত্তার জন্য email confirmation চালু রাখার পরামর্শ দেওয়া হচ্ছে।

SETUP 2 — HTML-এ API key
index.html-এ এই দুই লাইন খুঁজে নিজের Project URL ও publishable/anon key বসাও:
const SUPABASE_URL = "PASTE_SUPABASE_PROJECT_URL_HERE";
const SUPABASE_ANON_KEY = "PASTE_SUPABASE_PUBLISHABLE_OR_ANON_KEY_HERE";
শুধু publishable/anon key ব্যবহার করবে। service_role/secret key কখনো HTML-এ দেবে না।

SETUP 3 — প্রথম Admin তৈরি
1. ওয়েবসাইটে Customer Login tab থেকে নিজের ইমেইল দিয়ে Create Customer Account করো।
2. Email confirmation চালু থাকলে ইমেইল confirm করো।
3. Supabase Dashboard → SQL Editor-এ গিয়ে নিচের query-তে নিজের ইমেইল বসিয়ে Run করো:
   UPDATE public.profiles
   SET role='admin'
   WHERE lower(email)=lower('YOUR-ADMIN-EMAIL@example.com');
4. Query-তে নিজের email বসাতে হবে, উদাহরণ হিসেবে দেওয়া email-টি 그대로 ব্যবহার করবে না।
5. Website-এ লগআউট করে Admin Login tab থেকে একই email/password দিয়ে লগইন করো।
6. Admin role না থাকলে Admin Login হবে না।

SETUP 4 — Customer
1. অন্য ব্যক্তি Customer Login tab → Create Customer Account দিয়ে account তৈরি করবে।
2. Confirm email করে Customer Login করবে।
3. Admin video পোস্ট করলে customer Published videos তালিকায় পাবে।

SETUP 5 — Publish
index.html-কে HTTPS static hosting-এ publish করো (Netlify, Cloudflare Pages, Vercel static site ইত্যাদি)। Supabase URL Configuration-এ deployed site URL যোগ করো। file:// দিয়ে না চালিয়ে hosting URL ব্যবহার করো।

নিরাপত্তা ও সীমাবদ্ধতা
- ভিডিও 500 MB পর্যন্ত; plan/storage quota, bandwidth ও network speed প্রযোজ্য।
- Private bucket public URL নয়। Logged-in customer published video দেখতে পারে; admin upload/delete করতে পারে।
- Signed URL 5 মিনিটের জন্য valid। কেউ URL পেলে expiry পর্যন্ত ব্যবহার করতে পারে; তাই share কোরো না।
- Viewer স্ক্রিন রেকর্ড করতে পারে; ওয়েবসাইট সব রেকর্ডিং আটকাতে পারে না।
- এই setup নতুন Supabase project-এ সবচেয়ে সহজ। আগের version-এর SQL চালানো project-এ policy নাম/role constraints আলাদা থাকলে আগে backup নিয়ে SQL review করো।
- Production-এ যাওয়ার আগে test customer দিয়ে admin upload, customer playback, customer upload blocked, customer delete blocked—এই চারটি পরীক্ষা করো।
